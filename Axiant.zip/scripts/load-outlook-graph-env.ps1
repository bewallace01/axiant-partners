# Copy this file to load-outlook-graph-env.ps1 and fill in the values.
# Do not commit load-outlook-graph-env.ps1 (it contains the client secret).

$env:AXIANT_TENANT_ID     = "a3d2307c-af4b-49c2-b669-28029870fa00"
$env:AXIANT_CLIENT_ID     = "e42ea792-dbe8-42f4-a55a-9436202eb16d"
$env:AXIANT_CLIENT_SECRET = "2iu8Q~8XoWFK1Z1zZOnMSMKrdnSCQRPgxCpwMdlA" 
$env:AXIANT_FROM_EMAIL    = "alex@axiantpartners.com"
$env:AXIANT_REPLY_TO      = "alex@axiantpartners.com"
# Use text signature (replies will show your full contact card with picture)
$env:AXIANT_SIGNATURE_FILE = (Join-Path $PSScriptRoot "outreach-signature.txt")

Write-Host "Graph env loaded for $env:AXIANT_FROM_EMAIL (no app password)" -ForegroundColor Green
Write-Host "Run: python .\scripts\send_vendor_outreach_graph.py --input `"PATH_TO_recipients.txt`"" -ForegroundColor Cyan
